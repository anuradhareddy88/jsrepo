const color ='red';
function start(){
    const message = 'hi',
    const color  = 'blue'
    console.log(color);
}
start();