const person ={
    name :'anu'
};

person.color='white';
person.walk = function(){}

//delete person.color;
//delete person.walk;

console.log(person);


