// string premitive(string,number,null)
const greet = 'hello'   // type of greet is string

// string object
const another = new string('hi') // another is object

//string method and properties
const message  = 'this is my first message';
// message.indexOf('my') (it gives index number) 8
//message.replace('first','second') 
//message.UpperCase()
//message.trim // trim the empty spaces
//message.split

