//how to copy the object
const circle = {
    radius:1,
    draw(){
        console.log('draw');
    }
};
//create another circle(object)
const another = {};
for (let key in circle)
another[key] = circle[key];
    console.log (another);

//rest method
const another1 ={...circle};
    console.log(another1);

//assign method
const another3 = Object.assign({},circle);  // here circle is sourse,object is method
      console.log(another3)