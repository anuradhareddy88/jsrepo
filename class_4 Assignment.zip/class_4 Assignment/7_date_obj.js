//date is constructor function
const now = new Date();
const date1 = new Date('sep 4 2021 10pm');
const date2  = new Date(2021, 10, 5, 10);

now.getFullYear(2021);
//now.toDateString()
//now.toTimeString()
//now.toISOString()
