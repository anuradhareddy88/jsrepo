//for loop
const salaries= {
    anu : 24000,
    mounika : 34000,
    siri : 55000
}

for ( let i in salaries) {

    let salary = "$" + salaries[i];

    console.log(`${i} : ${salary}`);
}

// 2 ex : forloop

const arr = [ 'anu', 1, 'sachi' ];

for (let x in arr) {
    console.log(arr[x]);
}

//while loop

let count = 1;
while (count < 10) {
    console.log(count);
    count +=2;
}

//while loop ex2

let i = 1, n = 5;
while (i <= n) {
    console.log(i);
    i += 1;
}