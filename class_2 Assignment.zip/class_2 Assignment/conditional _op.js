var mySal = 500;
var friendSal = 1000;

if( mySal > friendSal)
{
console.log("My Salary is greater than friend salary");
}
else if(mySal < friendSal)
{
console.log("My Salary is less than friend salary");
}
else if(mySal == friendSal)
{
console.log("My Salary is equal to friend salary");
}

//Swich....case
let role = 'guest';
switch(role){
    case'guest':
    console.log('Guest User');
    break;
    case'moderator':
    console.log('moderator');
    break;
    default:
        console.log('unknown User');
}