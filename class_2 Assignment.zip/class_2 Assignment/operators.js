// Arithmetic operators
 let x = 10;
 let y = 2;
  console.log(x+y);
  console.log(x-y);
  console.log(x*y);
  console.log(x/y);
  console.log(x%y);
  console.log(x**y);

//Increment operators (++) 
let a = 10;
let b = 2 ;
console.log(a);
console.log(++a);
console.log(a);
console.log(a++);

// decrement operators (--)
c = 20;
console.log(c);
console.log(--c);
console.log(c);

// assignment operators (=)
let d = 10;
console.log(d += 5 );
console.log(d= d+5);
console.log(d%= 2);
console.log(d*= 2);

// comparion operators (relational(>,>=,<,<=))
 let z =2;
 console.log(z>4);
 console.log(z>=2);
 console.log(z<2);
 console.log(z<=2);
 console.log(z>=4);

// equality operators((===),(==)) 
let k = 'anu';
console.log(k===1);
console.log(k!==1)
console.log(k==1 );
console.log(1=='1');

let j= 1;
console.log(j===1);
console.log(j!==1);

// Ternary operators(?)
let points = 200;
let type = points > 100 ? 'gold' : 'silver';
console.log(type);

//logical operators with non booleans( (&&)and,(||)or)
 console.log(true && false);
 console.log(false && false);
 console.log(true&& true);
//&&
 let oldcity = true;
 let newcity = true;
 let city= oldcity && newcity;
 console.log(city);

//||

let color = 'red';
let addcolor = 'blue';
let newcolor = color && addcolor;
console.log(newcolor);

let firstname='anu';
let lastname = 'reddy';
let fullname = firstname||lastname;
console.log(fullname);

//swapping variable

let redcup = 'red';
let bluecup = 'blue';
let emptycup = redcup;
let redcup = bluecup;
let bluecup= emptycup;
console.log(redcup);
console.log(bluecup);




