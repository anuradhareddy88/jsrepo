// (A) ORIGINAL ARRAYS
var arrA = ["anu", "siri"];
var arrB = ["sachi", "ridhu"];

// (B) APPEND ARRAY
var arrC = [...arrA, "susi", "deepu"];
console.log(arrC);

// (C) COMBINE ARRAYS
var arrD =[...arrA, ...arrB];
console.log(arrD);

//object
let object1 = {
    firstName: "sandhya",
    age: 24, 
    salary: 300,
}

let object2 = {
    lastName: "dany",
    height: '20 meters',
    weight: '70 KG'
}

let object3 = {...object1, ...object2}
console.log(object3);