//filtering
const numbers = [2,4,-5,-1,7,8,9]
const filtered = numbers.filter(function(number){
    return number>=0;
});
//const filtered=numbers.filter(n>=n>=0);
console.log(filtered);

