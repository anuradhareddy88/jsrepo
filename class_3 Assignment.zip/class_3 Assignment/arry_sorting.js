//sort
const numbers =[1,2,6,8,4,5];
numbers.sort();
console.log(numbers);

//reverse
numbers.reverse();
console.log(numbers);
