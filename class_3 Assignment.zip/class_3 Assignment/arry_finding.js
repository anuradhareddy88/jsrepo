const numbers= [2,4,5,6,7,8,4,5,5,4];
console.log(numbers.indexOf(4));

console.log(numbers.indexOf('a'));

console.log(numbers.lastIndexOf(5));

console.log(numbers.includes(2));