const courses = [
    {id:1 , name:'anu'},
    {id:2, name:'sachi'}
]
//console.log(courses.include({id:1,name:'anu'}));

const course = courses.find(function(course){
     return course.name ==='anu';
});
console.log(course);