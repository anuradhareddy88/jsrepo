const numbers = [1,2,3,4,5]
for(let number of numbers)
console.log(number);

//function method
numbers.forEach(function(number){
    console.log(number);
})

// index method
numbers.forEach((number,index)=>console.log(index,number));