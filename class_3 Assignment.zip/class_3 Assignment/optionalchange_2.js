const person = {
    name : "dany",
    color : "white",
    vehicle:{
        year:2018,
        warranty:{
            expirydate:2030
        }
    }
     
}
//tertory operator(?)
const vehicleyear = person.vehicle? person.vehicle.year: undefined;
//optional changing operator(?.)
const vehicleyear = person.vehicle?.year;
console.log(vehicleyear);
const warrantyexpirydate = person.vehicle?.warranty?.expirydate;
console.log(warrantyexpirydate);

//finction level
console.log(person.vehicle?.drive?.());

//nullish (??)
const vehicleyear = person.vehicle?.newyear?? 2050;
console.log(vehicleyear);