const names =['anu','sachi','ridhu','siri'];
//end( remove last element)
const last = names.pop();
console.log(last);

// first
const first = names.shift();
console.log(first);

//last
names.splice(2,2);
console.log(names);