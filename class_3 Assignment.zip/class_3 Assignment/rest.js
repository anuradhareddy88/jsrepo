const obj1 = {
    name: "deepu",
    Sex: "feMale"
  }
  console.log(obj1);        
  
  const obj2 = {
    ...obj1,
  age: 25              
  }
  console.log(obj2);
  
  obj1["height"] = "5'4 ft";
  console.log(obj1);
    