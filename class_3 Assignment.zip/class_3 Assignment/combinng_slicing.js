const first =[1,2,3,4];
const second =[5,6,7,8,9];
const combined = first.concat(second);
console.log(combined);

const slice = combined.slice(2,6);
console.log(slice);

//copy
const slicecopy = combined.slice();
console.log(slicecopy);