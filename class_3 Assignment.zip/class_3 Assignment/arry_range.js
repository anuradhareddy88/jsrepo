const numbers=arrayFromRange[1,8];
console.log(numbers);
