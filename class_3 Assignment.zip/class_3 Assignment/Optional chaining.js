//Optional chaining (?.)
//(The optional chaining operator (?.) enables you to read the 
//value of a property located deep within a chain of connected
 //objects without having to check that each reference in the chain is valid.)

 

let potentiallyNullObj = null;
let x = 10;
let prop = potentiallyNullObj?.[x++];

console.log(x);


let customer = {
    name: "Carl",
    details: { age: 82 }
  };
  const customerCity = customer?.city ?? "Unknown city";
  console.log(customerCity); // Unknown city
