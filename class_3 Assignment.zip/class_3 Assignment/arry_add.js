const numbers =[ 2,4,6];
console.log(numbers);

//end
numbers.push(8,9);
console.log(numbers);

//beginning
numbers.unshift(1,2);
console.log(numbers);

//middle
numbers.splice(2,0,'anu');
console.log(numbers);